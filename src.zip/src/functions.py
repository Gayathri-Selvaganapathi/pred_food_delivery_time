import geopy
import pandas as pd
import numpy as np
from geopy.distance import geodesic
from datetime import datetime
import streamlit as st
from sklearn.preprocessing import LabelEncoder,StandardScaler 

def extract_date_features(data):
    data["day"] = data.Order_Date.dt.day
    data["month"] = data.Order_Date.dt.month
    data["quarter"] = data.Order_Date.dt.quarter
    data["year"] = data.Order_Date.dt.year
    data['day_of_week'] = data.Order_Date.dt.day_of_week.astype(int)
    data["is_month_start"] = data.Order_Date.dt.is_month_start.astype(int)
    data["is_month_end"] = data.Order_Date.dt.is_month_end.astype(int)
    data["is_quarter_start"] = data.Order_Date.dt.is_quarter_start.astype(int)
    data["is_quarter_end"] = data.Order_Date.dt.is_quarter_end.astype(int)
    data["is_year_start"] = data.Order_Date.dt.is_year_start.astype(int)
    data["is_year_end"] = data.Order_Date.dt.is_year_end.astype(int)
    data['is_weekend'] = np.where(data['day_of_week'].isin([5,6]),1,0)

    data.drop(['Order_Date'], axis=1, inplace=True)

    return data

# Function to validate time format
def validate_time_input(time_str):
    try:
        return datetime.strptime(time_str, "%H:%M").time()
    except ValueError:
        st.error("Invalid time format. Please use HH:MM format.")
        return None

def calculate_distance(restaurant_lat, restaurant_long, delivery_lat, delivery_long):
    # Define the coordinates as tuples
    restaurant_coordinates = (restaurant_lat, restaurant_long)
    delivery_coordinates = (delivery_lat, delivery_long)
    
    # Calculate the distance
    distance = geodesic(restaurant_coordinates, delivery_coordinates).kilometers
    
    return distance

def preprocess_data(input_data):
    # Convert Order_Date to datetime before extracting features
    input_data['Order_Date'] = pd.to_datetime(input_data['Order_Date'], errors='coerce')
    input_data = extract_date_features(input_data)

    # Encode categorical variables (assuming you used one-hot encoding during training)
    categorical_columns = input_data.select_dtypes(include='object').columns
    label_encoder = LabelEncoder()
    input_data[categorical_columns] = input_data[categorical_columns].apply(lambda col: label_encoder.fit_transform(col))

    # Create a StandardScaler object
    scaler = StandardScaler()

    # Fit the scaler on the training data
    scaler.fit(input_data)

    # Perform standardization on the training data
    input_data = scaler.transform(input_data)

    return input_data