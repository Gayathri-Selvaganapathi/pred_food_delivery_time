import streamlit as st
from datetime import datetime
import numpy as np
import pandas as pd
import pickle
from functions import extract_date_features, validate_time_input, calculate_distance, preprocess_data

# Load the saved model
loaded_model = pickle.load(open('best_model.sav', 'rb'))

st.title("Food Delivery Time Prediction")

# Define input fields
age = st.number_input("Delivery Person Age", min_value=18, max_value=70)
rating = st.number_input("Delivery Person Ratings", min_value=1.0, max_value=5.0, step=0.1)
rest_lat = st.number_input("Restaurant Latitude")
rest_long = st.number_input("Restaurant Longitude")
del_lat = st.number_input("Delivery Location Latitude")
del_long = st.number_input("Delivery Location Longitude")
weather = st.selectbox("Weather Conditions", ['Sunny','Stormy' ,'Sandstorms', 'Cloudy', 'Fog', 'Windy'])
traffic = st.selectbox("Road Traffic Density", ["Low", "Medium", "High", "Jam"])
vehicle_condition = st.number_input("Vehicle Condition", min_value=1, max_value=5)
order_type = st.selectbox("Type of Order", ['Snack ' ,'Drinks ', 'Buffet ', 'Meal '])
type_of_vehicle = st.selectbox("Type of Vehicle", ['motorcycle ' ,'scooter ' ,'electric_scooter ', 'bicycle '])
multiple_deliveries = st.number_input("Multiple Deliveries", min_value=0, max_value=3)
festival = st.selectbox("Festival", ["No", "Yes"])
city = st.selectbox("City", ['Urban ' ,'Metropolitian ','Semi-Urban'])
city_code = st.selectbox("City Code",['INDO', 'BANG', 'COIMB', 'CHEN', 'HYD', 'RANCHI', 'MYS', 'DEH', 'KOC', 'PUNE',
 'LUDH', 'KNP', 'MUM', 'KOL', 'JAP', 'SUR', 'GOA', 'AURG', 'AGR', 'VAD', 'ALH', 'BHP'])

# Initialize default values
current_datetime = datetime.now()
default_order_date = current_datetime.date()

# Create input widgets
order_date = st.date_input("Order Date", default_order_date)
ordered_time = st.text_input("Order Placed Time", current_datetime.strftime("%H:%M"))
order_picked_time = st.text_input("Order Prepare Time", current_datetime.strftime("%H:%M"))
ordered_time = validate_time_input(ordered_time)
order_prepare_time = validate_time_input(order_picked_time)
# Combine the date and time inputs into a single datetime object
order_datetime = datetime.combine(order_date, ordered_time)
prepare_datetime = datetime.combine(order_date, order_prepare_time)
# Assuming the model requires the difference in minutes as input features
order_prepare_time = (prepare_datetime - order_datetime).total_seconds() / 60.0
distance = calculate_distance(rest_lat, rest_long, del_lat, del_long)

input_data = pd.DataFrame({
        'Delivery_person_Age': [age],
        'Delivery_person_Ratings': [rating],
        'Restaurant_latitude': [rest_lat],
        'Restaurant_longitude': [rest_long],
        'Delivery_location_latitude': [del_lat],
        'Delivery_location_longitude': [del_long],
        'Weather_conditions': [weather],
        'Road_traffic_density': [traffic],
        'Vehicle_condition': [vehicle_condition],
        'Type_of_order': [order_type],
        'Type_of_vehicle': [type_of_vehicle],
        'multiple_deliveries': [multiple_deliveries],
        'Festival': [festival],
        'City': [city],
        'City_code': [city_code],
        'Order_Prepare_Diff': [order_prepare_time],
        'Order_Date': [order_date],
        'distance': [distance]
    })

preprocessed_data = preprocess_data(input_data)

if st.button("Predict Delivery Time"):
    # Preprocess inputs as done during training

    # Use the model to predict
    prediction = loaded_model.predict(preprocessed_data)[0]
    
    st.write(f"Estimated Delivery Time: {prediction} minutes")
  
